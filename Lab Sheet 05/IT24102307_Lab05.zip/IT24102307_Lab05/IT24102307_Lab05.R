setwd('C:\\Users\\IT24102307\\Desktop\\Lab 05')
getwd()

#1
Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")
fix(Delivery_Times)
attach(Delivery_Times)

#2
hist(Delivery_Time_.minutes.,main = "Delivery Time(Minutes)",breaks=seq(20,70,length=10),right=TRUE)

#3
#The distribution is approximately symmetric with a mild right skew, peaking around 35-40 minutes.

#4
freq_table<-hist(Delivery_Time_.minutes.,breaks=seq(20,70,length=10))
cum_freq<-cumsum(freq_table$counts)

plot(freq_table$mids,cum_freq,type="o",main="cumulative Frequency Polygon",
     xlab="Delivery Time", ylab="Cumulative Frequency")
