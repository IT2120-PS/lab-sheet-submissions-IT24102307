setwd('C:\\Users\\msi\\Desktop\\Sliit Uni\\2 YR 1 Sem\\Probability and Statistics - IT2120\\Labs\\Lab 6')

#Exercise
#1

#(i)
#Binomial Distribution with p=0.95 and n=50

#(ii)
pbinom(46, 50, 0.85, lower.tail = FALSE)


#2

#(i)
#The random variable $ X $ is the number of customer calls received in an hour.

#(ii)
#Poisson Distribution with lambda = 12

#(iii)
dpois(15, lambda=12)
